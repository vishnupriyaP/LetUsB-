
public enum SortCriterion {

	
	SOURCE,
	TOPIC,
	SUBJECT,
	LENGTH,
	DATE_TIME;
	
	
	/**
	 * <P>
	 * This method will convert the enumeration to a prettier version.
	 * </P>
	 */
	@Override
	public String toString() {
		return null;
		
	}
}
