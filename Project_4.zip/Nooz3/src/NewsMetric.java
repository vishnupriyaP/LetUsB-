
public enum NewsMetric {

	LENGTH,
	COUNT;

	/**
	 * <P>
	 * This method will convert the enumeration to a prettier version.
	 * </P>
	 */
	@Override
	public String toString() {
		return null;
		
	}
	
}
