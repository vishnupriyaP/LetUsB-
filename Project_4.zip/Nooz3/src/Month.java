
public enum Month {
	JANUARY,
	FEBRUARY,
	MARCH,
	APRIL,
	MAY,
	JUNE,
	JULY,
	AUGUST,
	SEPTEMBER,
	OCTOBER,
	NOVEMBER,
	DECEMBER;
	
	/**
	 * <P>
	 * This method will convert the enumeration to a prettier version.
	 * </P>
	 */
	@Override
	public String toString() {
		return null;
		
	}
	/**
	 * <P>
	 * This method will convert from an enumeration to an integer value.
	 * </P>
	 */
	private void toInt() {
		
	}
	/**
	 * <P>
	 * This method will convert an integer to a month enumeration.
	 * </P>
	 * @param x The integer to convert to a date.
	 */
	//TODO he didnt specify variable name
	public static void fromInt(int x) {
		
	}

	
}
